
import { motion } from "framer-motion";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div className="relative overflow-hidden">
      {/* Hero Section */}
      <section className="min-h-[90vh] flex flex-col items-center justify-center text-center px-4 relative">
        <div className="magic-circle absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none">
          <div className="w-[800px] h-[800px] rounded-full border-2 border-pink-300/20"></div>
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="z-10"
        >
          <HoverCard>
            <HoverCardTrigger asChild>
              <div className="text-center cursor-pointer">
                <h1 className="text-5xl md:text-7xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-500 via-pink-600 to-pink-400 mb-4">
                  <span className="inline-block">ISABELA ETORE LOPES</span>
                </h1>
              </div>
            </HoverCardTrigger>
            <HoverCardContent className="w-80 bg-white/90 border border-pink-200">
              <div className="flex justify-between space-x-4">
                <div className="space-y-1">
                  <h4 className="text-xl font-semibold text-pink-600">✨ Boas-vindas!</h4>
                  <p className="text-sm text-gray-600">
                    "É no mundo da magia da programação onde transformamos ideias em realidade."
                  </p>
                </div>
              </div>
            </HoverCardContent>
          </HoverCard>
          
          <p className="text-xl md:text-2xl text-pink-600 mt-4 mb-8">
            Desenvolvedora FrontEnd & BackEnd
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              className="bg-gradient-to-r from-pink-700 to-pink-500 hover:from-pink-600 hover:to-pink-400 border-none"
            >
              <Link to="/certificates">Ver Certificados</Link>
            </Button>
            
            <Button
              asChild
              variant="outline"
              className="border-pink-600 text-pink-600 hover:bg-pink-50"
            >
              <Link to="/contact">Entre em Contato</Link>
            </Button>
          </div>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 1 }}
          className="absolute bottom-12 left-0 right-0 flex justify-center"
        >
          <div className="animate-bounce">
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="text-pink-500"
            >
              <path
                d="M12 17L12 3M12 17L6 11M12 17L18 11"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
        </motion.div>
      </section>
    </div>
  );
};

export default Home;

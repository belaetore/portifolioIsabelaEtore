import { Mail, Github, Linkedin } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-black/80 border-t border-pink-900/30 py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <p className="text-pink-200 text-sm">© {new Date().getFullYear()} - Todos os direitos reservados.</p>
          </div>
          
          <div className="flex items-center gap-6">
            <a 
              href="mailto:isabela.etore.dev2024@gmail.com" 
              className="text-pink-300 hover:text-pink-100 transition-colors"
              aria-label="Email"
            >
              <Mail size={20} />
            </a>
            <a 
              href="https://github.com/belaetore" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-pink-300 hover:text-pink-100 transition-colors"
              aria-label="GitHub"
            >
              <Github size={20} />
            </a>
            <a 
              href="https://linkedin.com/in/seu-usuario" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-pink-300 hover:text-pink-100 transition-colors"
              aria-label="LinkedIn"
            >
              <Linkedin size={20} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
